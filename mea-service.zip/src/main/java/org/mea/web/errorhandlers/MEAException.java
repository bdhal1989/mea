package org.mea.web.errorhandlers;

public class MEAException extends Exception {
	
	public MEAException(String errorMessage) {  
	    super(errorMessage);  
	    }  

}
