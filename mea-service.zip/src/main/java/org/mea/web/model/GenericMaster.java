// Source code is decompiled from a .class file using FernFlower decompiler.
package org.mea.web.model;

public class GenericMaster {
   private String id;
   private String name;

   public GenericMaster() {
   }

   public String getId() {
      return this.id;
   }

   public void setId(String id) {
      this.id = id;
   }

   public String getName() {
      return this.name;
   }

   public void setName(String name) {
      this.name = name;
   }
}
